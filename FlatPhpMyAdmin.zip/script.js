window.browser = (function () {
  return window.msBrowser ||
    window.browser ||
    window.chrome;
})();


//window.onload = function() {//window.onload doesnt work on firefox
  if(/^.+\/.+\|\sphpMyAdmin\s[\d\.]+$/.test(document.title)){
        var head = document.head;
        var link = document.createElement("link");
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href =browser.extension.getURL("style.css");
        head.appendChild(link);
      }
//};